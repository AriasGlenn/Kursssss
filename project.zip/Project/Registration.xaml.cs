﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public string connectionString;
        public Registration()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection con;
            SqlCommand cmd;
            SqlDataReader dr;

            con = new SqlConnection();
            con.ConnectionString = connectionString;

            cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = "SELECT * FROM dbo.Тип_Пользователя";
            try
            {
                dr = cmd.ExecuteReader();
                Listok.Items.Clear();

                while (dr.Read())
                {
                    string sLastName = (string)dr["Название"];
                    if ((int)dr["Id_типа_пользователя"]!=2)
                    Listok.Items.Add(sLastName);
                }


                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (name.Text != "" || surname.Text != "" || otch.Text != "" || year.Text != "" || adress.Text != "" || login.Text != "" || password.Text != "" || Listok.SelectedItems.Count != 0)
            {   try
                {
                    string Name = name.Text;
                    string Surname = surname.Text;
                    string Otch = otch.Text;
                    int Year = Convert.ToInt32(year.Text);
                    string Adress = adress.Text;
                    string Login = login.Text;
                    string Password = password.Text;

                    int typeId = 2;
                    string sql = "INSERT INTO Пользователь (Id_типа_пользователя, Фамилия, Имя, Отчество, Год_Рождения, Адрес, Пароль, Логин) VALUES (@typeId, @Surname, @Name, @Otch, @Year, @Adress, @Password, @Login)";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@typeId", typeId);
                            command.Parameters.AddWithValue("@Surname", Surname);
                            command.Parameters.AddWithValue("@Name", Name);
                            command.Parameters.AddWithValue("@Otch", Otch);
                            command.Parameters.AddWithValue("@Year", Year);
                            command.Parameters.AddWithValue("@Adress", Adress);
                            command.Parameters.AddWithValue("@Password", Password);
                            command.Parameters.AddWithValue("@Login", Login);

                            command.ExecuteNonQuery();
                        }
                        connection.Close();
                    }
                    int typeUserId = int.MaxValue;
                    int userId;
                    string Doljnost = Listok.SelectedItem.ToString();
                    SqlConnection con;
                    SqlCommand cmd;
                    SqlDataReader dr;

                    con = new SqlConnection();
                    con.ConnectionString = connectionString;

                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();
                    cmd.CommandText = "SELECT * FROM dbo.Тип_Пользователя WHERE Название='" + Doljnost + "'";
                    try
                    {
                        dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            typeUserId = Convert.ToInt32(dr["Id_типа_Пользователя"]);
                        }


                        con.Close();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }
                    con.Close();
                    con = new SqlConnection();
                    con.ConnectionString = connectionString;
                    userId = 0;
                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();
                    cmd.CommandText = "SELECT * FROM dbo.Пользователь WHERE Логин='" + Login + "'";
                    try
                    {
                        dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            userId = Convert.ToInt32(dr["Id_Пользователя"]);
                        }


                        con.Close();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }
                    con.Close();
                    sql = "INSERT INTO Заявка_Регистрация (Id_пользователя, Id_типа_пользователя) VALUES (@userId, @typeUserId)";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@userId", userId);
                            command.Parameters.AddWithValue("@typeUserID", typeUserId);

                            command.ExecuteNonQuery();
                        }
                        connection.Close();
                    }
                }
                catch (Exception exc) { MessageBox.Show(exc.Message); }
            MainWindow q = new MainWindow();
            q.Show();
            this.Close();
        }
            else { MessageBox.Show("Заполни все поля"); }
        }
    }
}
