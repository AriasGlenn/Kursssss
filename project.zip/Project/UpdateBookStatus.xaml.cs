﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace Project
{
    public partial class UpdateBookStatus : Window
    {
        private readonly string _connectionString;

        public UpdateBookStatus()
        {
            InitializeComponent();
            _connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            LoadBooks();
            LoadStatuses();
        }

        private void LoadBooks()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "SELECT Id_Книги AS Id, Название AS Name FROM Книга";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable booksTable = new DataTable();
                adapter.Fill(booksTable);
                BooksComboBox.ItemsSource = booksTable.DefaultView;
            }
        }

        private void LoadStatuses()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "SELECT Id_статуса AS Id, Название AS Name FROM Статус";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable statusesTable = new DataTable();
                adapter.Fill(statusesTable);
                StatusComboBox.ItemsSource = statusesTable.DefaultView;
            }
        }

        private void OnUpdateStatusClick(object sender, RoutedEventArgs e)
        {
            if (BooksComboBox.SelectedValue != null && StatusComboBox.SelectedValue != null)
            {
                int bookId = (int)BooksComboBox.SelectedValue;
                int statusId = (int)StatusComboBox.SelectedValue;

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    string query = "UPDATE Книга SET Id_Статуса = @StatusId WHERE Id_Книги = @BookId";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@StatusId", statusId);
                    command.Parameters.AddWithValue("@BookId", bookId);

                    connection.Open();
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Status updated successfully!");
            }
            else
            {
                MessageBox.Show("Please select both a book and a status.");
            }
        }
    }
}
