﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace Project
{
    /// <summary>
    /// Логика взаимодействия для Librarian.xaml
    /// </summary>
    public partial class Librarian : Window
    {
        private string currentTable = "";

        public Librarian()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            currentTable = "Книга"; // Set current table name
            using var conn = new SqlConnection("Data Source=LAPTOP-8082O78L\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False");
            var query = "SELECT Книга.Id_Книги AS Id, Автор.Фамилия AS Автор, Жанр.Название AS Жанр, Статус.Название AS Статус, Книга.Название, Книга.Количество_страниц AS [Количество страниц], Книга.Год_издания AS [Год издания] FROM Книга " +
                        "INNER JOIN Автор ON Автор.Id_Автора = Книга.Id_Автора " +
                        "INNER JOIN Жанр ON Жанр.Id_Жанра = Книга.Id_Жанра " +
                        "INNER JOIN Статус ON Статус.Id_статуса = Книга.Id_Статуса";
            var sqlAdapter = new SqlDataAdapter(query, conn);
            var dataTable = new DataTable();
            sqlAdapter.Fill(dataTable);
            dataGrid.ItemsSource = dataTable.DefaultView;
        }

        private void LoadData2()
        {
            currentTable = "Выдача"; // Set current table name
            using var conn = new SqlConnection("Data Source=LAPTOP-8082O78L\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False");
            var query = @"
                SELECT 
                    Выдача.Id_выдачи AS Id,
                    Книга.Название AS Книга, 
                    Пользователь.Фамилия AS Пользователь, 
                    Выдача.Дата_выдачи, 
                    Выдача.Дата_сдачи, 
                    Выдача.Просроченность
                FROM Выдача
                INNER JOIN Книга ON Выдача.Id_Книги = Книга.Id_Книги
                INNER JOIN Пользователь ON Выдача.Id_пользователя = Пользователь.Id_пользователя";

            var sqlAdapter = new SqlDataAdapter(query, conn);
            var dataTable = new DataTable();
            sqlAdapter.Fill(dataTable);
            dataGrid.ItemsSource = dataTable.DefaultView;
        }

        private void LoadAuthorData()
        {
            currentTable = "Автор"; // Set current table name
            using var conn = new SqlConnection("Data Source=LAPTOP-8082O78L\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False");
            var query = "SELECT Id_Автора AS Id, Фамилия, Имя, Отчество FROM Автор";

            var sqlAdapter = new SqlDataAdapter(query, conn);
            var dataTable = new DataTable();
            sqlAdapter.Fill(dataTable);
            dataGrid.ItemsSource = dataTable.DefaultView;
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            LibBookAdding window = new LibBookAdding();
            window.Show();
        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            LibAuthorAdding window = new LibAuthorAdding();
            window.Show();
        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            GiveBook window = new GiveBook();
            window.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            LoadData2();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            LoadAuthorData();
        }

        private void Change_status(object sender, RoutedEventArgs e)
        {
            UpdateBookStatus window = new UpdateBookStatus();
            window.Show();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (dataGrid.SelectedItem == null)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            DataRowView selectedRow = (DataRowView)dataGrid.SelectedItem;
            int id = (int)selectedRow.Row["Id"]; // Assuming the Id column is named "Id"

            using var conn = new SqlConnection("Data Source=LAPTOP-8082O78L\\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True;Encrypt=False");
            conn.Open();
            string query = "";

            switch (currentTable)
            {
                case "Книга":
                    query = "DELETE FROM Книга WHERE Id_Книги = @id";
                    break;
                case "Выдача":
                    query = "DELETE FROM Выдача WHERE Id_выдачи = @id"; // Assuming there's an Id_выдачи column
                    break;
                case "Автор":
                    query = "DELETE FROM Автор WHERE Id_Автора = @id";
                    break;
                    // Add more cases as needed
            }

            using var cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();

            // Refresh the data grid
            switch (currentTable)
            {
                case "Книга":
                    LoadData();
                    break;
                case "Выдача":
                    LoadData2();
                    break;
                case "Автор":
                    LoadAuthorData();
                    break;
                    // Add more cases as needed
            }
        }
    }
}
