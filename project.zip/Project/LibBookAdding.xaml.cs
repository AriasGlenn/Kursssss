﻿using Google.Protobuf.Collections;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace Project
{
    /// <summary>
    /// Логика взаимодействия для LibBookAdding.xaml
    /// </summary>
    public partial class LibBookAdding : Window
    {
        string connectionString;
        public LibBookAdding()
        {
            InitializeComponent();
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection con;
            SqlCommand cmd;
            SqlDataReader dr;

            con = new SqlConnection();
            con.ConnectionString = connectionString;

            cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = "SELECT * FROM dbo.Автор";
            try
            {
                dr = cmd.ExecuteReader();
                Author.Items.Clear();

                while (dr.Read())
                {
                    string sLastName = (string)dr["Фамилия"];
                    Author.Items.Add(sLastName);
                }


                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            con.Open();
            cmd.CommandText = "SELECT * FROM dbo.Жанр";
            try
            {
                dr = cmd.ExecuteReader();
                Janre.Items.Clear();

                while (dr.Read())
                {
                    string sLastName = (string)dr["Название"];
                    Janre.Items.Add(sLastName);
                }


                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            con.Open();
            cmd.CommandText = "SELECT * FROM dbo.Статус";
            try
            {
                dr = cmd.ExecuteReader();
                Status.Items.Clear();

                while (dr.Read())
                {
                    string sLastName = (string)dr["Название"];
                    Status.Items.Add(sLastName);
                }


                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Year.Text != "" || AmountPage.Text != "" || Name.Text != "" || Author.SelectedItem != null || Janre.SelectedItem != null || Status.SelectedItem != null)
            {
                try
                {
                    SqlConnection con;
                    SqlCommand cmd;
                    SqlDataReader dr;
                    con = new SqlConnection();
                    con.ConnectionString = connectionString;

                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    con.Open();
                    string name = Name.Text;
                    int year = Convert.ToInt32(Year.Text);
                    int AP = Convert.ToInt32(AmountPage.Text);
                    int AuthorID = 0;
                    int JanreID = 0;
                    int StatusID = 0;
                    cmd.CommandText = "SELECT * FROM dbo.Автор WHERE Фамилия='" + (string)Author.SelectedItem + "'";
                    try
                    {
                        dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            AuthorID = Convert.ToInt32(dr["Id_автора"]);
                        }


                        con.Close();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }

                    con.Open();
                    cmd.CommandText = "SELECT * FROM dbo.Жанр WHERE Название='" + (string)Janre.SelectedItem + "'";
                    try
                    {
                        dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            JanreID = Convert.ToInt32(dr["Id_жанра"]);
                        }


                        con.Close();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }

                    con.Open();
                    cmd.CommandText = "SELECT * FROM dbo.Статус WHERE Название='" + (string)Status.SelectedItem + "'";
                    try
                    {
                        dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            StatusID = Convert.ToInt32(dr["Id_статуса"]);
                        }


                        con.Close();
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                    }


                    string sql = "INSERT INTO Книга (Id_Автора, Id_Жанра, Id_Статуса, Название, Количество_страниц, Год_издания) VALUES (@AuthorId, @JanreId, @StatusId, @Name, @AP, @Year)";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@AuthorId", AuthorID);
                            command.Parameters.AddWithValue("@JanreId", JanreID);
                            command.Parameters.AddWithValue("@StatusId", StatusID);
                            command.Parameters.AddWithValue("@Name", name);
                            command.Parameters.AddWithValue("@AP", AP);
                            command.Parameters.AddWithValue("@Year", year);

                            command.ExecuteNonQuery();
                        }
                        connection.Close();
                    }

                }
                catch (Exception exc) { MessageBox.Show(exc.Message); }
            }
            else { MessageBox.Show("Заполни все поля"); }
        }
    }
}
