﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string connectionString;
        public MainWindow()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Registration window = new Registration();
            window.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SqlConnection con = null;
            try
            {
                SqlCommand cmd;
                SqlDataReader dr;

                con = new SqlConnection();
                con.ConnectionString = connectionString;

                cmd = new SqlCommand();
                cmd.Connection = con;

                con.Open();
                cmd.CommandText = "SELECT * FROM Пользователь WHERE Логин='" + Login.Text + "' AND Пароль='" + Password.Password + "'";
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    if ((string)dr["Логин"] != "" && (int)dr["Id_типа_пользователя"] == 1)
                    {
                        if (con != null && con.State == ConnectionState.Open)
                        {
                            con.Close();
                        }
                        Admin window = new Admin();
                        window.Show();
                    }
                    else if ((string)dr["Логин"] != "" && (int)dr["Id_типа_пользователя"] == 5)
                    {
                        if (con != null && con.State == ConnectionState.Open)
                        {
                            con.Close();
                        }
                        Librarian window = new Librarian();
                        window.Show();
                    }
                    else
                    {
                        MessageBox.Show("Пользователь не найден");
                    }
                }
                else
                {
                    MessageBox.Show("Пользователь не найден");
                }
            }
            catch (Exception exce)
            {
                MessageBox.Show(exce.ToString());
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }



    }
}