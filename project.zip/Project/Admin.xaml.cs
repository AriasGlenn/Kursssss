﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using MySql.Data.MySqlClient;
using Google.Protobuf.Collections;
using System.Xml.Linq;

namespace Project
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {

        public Admin()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection con;
            SqlCommand cmd;
            SqlDataReader dr;

            con = new SqlConnection();
            con.ConnectionString = connectionString;

            cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = "SELECT * FROM dbo.Пользователь WHERE Id_типа_пользователя='2'";
            try
            {
                dr = cmd.ExecuteReader();
                Listok.Items.Clear();

                while (dr.Read())
                {
                    string sLastName = (string)dr["Логин"];
                    Listok.Items.Add(sLastName);
                }


                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        private void Listok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string obj = (string)Listok.SelectedItem;
            string ticket="";


            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection con;
            SqlCommand cmd;
            SqlDataReader dr;

            con = new SqlConnection();
            con.ConnectionString = connectionString;

            cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = "SELECT * FROM dbo.Пользователь WHERE Логин='"+obj+"'";
            try
            {
                dr = cmd.ExecuteReader();


                while (dr.Read())
                {
                    string name = (string)dr["Имя"];
                    string surname = (string)dr["Фамилия"];
                    string otch = (string)dr["Отчество"];
                    ticket += "Фамилия: " + surname+ "\n";
                    ticket += "Имя: " + name + "\n";
                    ticket += "Отчество: " + otch + "\n\n";
                    Int32 birth_year = (Int32)dr["Год_рождения"];
                    ticket += "Год рождения"+birth_year.ToString()+"\n\n";
                    string log = (string)dr["Логин"];
                    ticket += "Логин: " + log+"\n";
                    string pas = (string)dr["Пароль"];
                    ticket += "Пароль: " + pas+"\n";
                    Ticket.Text = ticket;
                }


                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AgreeBut_Click(object sender, RoutedEventArgs e)
        {
            string obj = (string)Listok.SelectedItem;


            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection con;
            SqlCommand cmd;
            SqlDataReader dr;

            con = new SqlConnection();
            con.ConnectionString = connectionString;

            cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            int idus=0;
            cmd.CommandText = $"SELECT * FROM dbo.Пользователь WHERE Логин='{obj}'";
            try
            {
                
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    idus = (int)dr["Id_пользователя"];
                }
                dr.Close();
            }
            catch(Exception ex) { MessageBox.Show(ex.Message); }
            cmd.CommandText = "SELECT * FROM dbo.Заявка_Регистрация WHERE Id_пользователя='" + idus + "'";
            int idty = int.MaxValue;
            try
            {
                
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    idty = (int)dr["Id_типа_пользователя"];
                }
                dr.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            string sqlQuery = $"UPDATE Пользователь SET Id_типа_пользователя = '{idty}' WHERE Id_пользователя = '{idus}'";            
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
            sqlQuery = $"DELETE FROM Заявка_Регистрация WHERE Id_пользователя = '{idus}'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        private void DisagreeBut_Click(object sender, RoutedEventArgs e)
        {
            string obj = (string)Listok.SelectedItem;


            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection con;
            SqlCommand cmd;
            SqlDataReader dr;

            con = new SqlConnection();
            con.ConnectionString = connectionString;

            cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = "SELECT * FROM dbo.Пользователь WHERE Логин='" + obj + "'";
            try
            {
                int idus=int.MaxValue;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                     idus = (int)dr["Id_пользователя"];
                }
                dr.Close();
                string sqlQuery = $"DELETE FROM Пользователь WHERE Id_пользователя = '{idus}'";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                sqlQuery = $"DELETE FROM Заявка_Регистрация WHERE Id_пользователя = '{idus}'";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
                cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "SELECT * FROM dbo.Пользователь WHERE Id_типа_пользователя='2'";
                dr = cmd.ExecuteReader();
                Listok.Items.Clear();
                while (dr.Read())
                {
                    string sLastName = (string)dr["Логин"];
                    Listok.Items.Add(sLastName);
                }
                Ticket.Text = "";


                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
