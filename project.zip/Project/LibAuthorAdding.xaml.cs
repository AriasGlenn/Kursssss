﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.Configuration;
namespace Project
{
    /// <summary>
    /// Логика взаимодействия для LibAuthorAdding.xaml
    /// </summary>
    public partial class LibAuthorAdding : Window
    {
        string connectionString;
        public LibAuthorAdding()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Name.Text != "" || Surname.Text != "" || BirthDate.Text != "" || DeathDate.Text != "" || Biography.Text != "")
            {
                connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
                string pattern = @"\b\d{4}-\d{2}-\d{2}\b";
                string name = Name.Text;
                string surname = Surname.Text;
                string second = SecondName.Text;
                string db = BirthDate.Text;
                string dd = DeathDate.Text;
                string bio = Biography.Text;

                string sql = "INSERT INTO Автор (Имя, Фамилия, Отчество, Дата_рождения, Дата_смерти, Краткая_биография) VALUES (@Name, @Surname, @Second, @DB, @DD, @Bio)";

                bool isDbValid = Regex.IsMatch(db, pattern);
                bool isDdValid = Regex.IsMatch(dd, pattern);
                if (isDbValid & isDdValid)
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        using (SqlCommand command = new SqlCommand(sql, connection))
                        {
                            command.Parameters.AddWithValue("@Name", name);
                            command.Parameters.AddWithValue("@Surname", surname);
                            command.Parameters.AddWithValue("@Second", second);
                            command.Parameters.AddWithValue("@DB", db);
                            command.Parameters.AddWithValue("@DD", dd);
                            command.Parameters.AddWithValue("@Bio", bio);

                            command.ExecuteNonQuery();
                        }
                        connection.Close();
                    }
                else MessageBox.Show("Проверьте дату");
            }
            else MessageBox.Show("Заполните все поля");
        }
    }
}
