﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace Project
{
    public partial class GiveBook : Window
    {
        private readonly string _connectionString;

        public GiveBook()
        {
            InitializeComponent();
            _connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            LoadBooks();
            LoadUsers();
        }

        private void LoadBooks()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = @"
                    SELECT Id_Книги AS Id, Название AS Name 
                    FROM Книга 
                    WHERE Id_Книги NOT IN (SELECT Id_Книги FROM Выдача)";

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable booksTable = new DataTable();
                adapter.Fill(booksTable);
                BooksComboBox.ItemsSource = booksTable.DefaultView;
            }
        }

        private void LoadUsers()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("SELECT Id_пользователя AS Id, (Фамилия + ' ' + Имя) AS FullName FROM Пользователь WHERE Id_типа_пользователя=3", connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable usersTable = new DataTable();
                adapter.Fill(usersTable);
                UsersComboBox.ItemsSource = usersTable.DefaultView;
            }
        }

        private void OnSubmit(object sender, RoutedEventArgs e)
        {
            if (BooksComboBox.SelectedValue != null && UsersComboBox.SelectedValue != null
                && IssueDatePicker.SelectedDate != null && ReturnDatePicker.SelectedDate != null)
            {
                int bookId = (int)BooksComboBox.SelectedValue;
                int userId = (int)UsersComboBox.SelectedValue;
                DateTime issueDate = IssueDatePicker.SelectedDate.Value;
                DateTime returnDate = ReturnDatePicker.SelectedDate.Value;
                bool isOverdue = OverdueCheckBox.IsChecked ?? false;

                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    SqlCommand command = new SqlCommand("INSERT INTO Выдача (Id_Книги, Id_пользователя, Дата_выдачи, Дата_сдачи, Просроченность) VALUES (@BookId, @UserId, @IssueDate, @ReturnDate, @Overdue)", connection);
                    command.Parameters.AddWithValue("@BookId", bookId);
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@IssueDate", issueDate);
                    command.Parameters.AddWithValue("@ReturnDate", returnDate);
                    command.Parameters.AddWithValue("@Overdue", isOverdue);

                    connection.Open();
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Книга выдана");
            }
            else
            {
                MessageBox.Show("Заполните все поля.");
            }
        }
    }
}
